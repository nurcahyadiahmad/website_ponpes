<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Yayasan Pendidikan Alishlah Hafiez Arridho - Home</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?= base_url(); ?>assets2/img/logoponpes.gif" rel="icon">
  <link href="<?= base_url(); ?>assets2/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?= base_url(); ?>assets2/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>assets2/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>assets2/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= base_url(); ?>assets2/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>assets2/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>assets2/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?= base_url(); ?>assets2/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Green - v4.6.0
  * Template URL: https://bootstrapmade.com/green-free-one-page-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
         <img src="<?= base_url(); ?>assets2/img/logoponpes.gif" width="20px">&nbsp; Yayasan Pendidikan Alishlah Hafiez Arridho
       
      </div>
      <div class="social-links d-none d-md-block">
        <i class="bi bi-telephone-fill telephone-icon"></i> 085277816339 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <i class="bi bi-envelope-fill"></i><a href="https://mail.google.com" target="_BLANK">alishlahhafiezarridho@gmail.com</a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center">

     <!-- <h5 class="logo me-auto"><a href="index.php">Yayasan Pendidikan Alishlah Hafiez Arridho</a></h5>-->
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Beranda</a></li>
          <li><a class="nav-link scrollto" href="#about">Profil</a></li>
          <li><a class="nav-link scrollto" href="#visi">Visi Misi</a></li>
          <li><a class="nav-link scrollto" href="#jurusan">Ilmu Pendidikan</a></li>
          <li><a class="nav-link scrollto " href="#guru">Guru</a></li>
          <li><a class="nav-link scrollto " href="#portfolio">Galeri</a></li>
         <!--  <li><a class="nav-link scrollto" href="#sarana">Sarana & Prasarana</a></li> -->
          <li><a class="nav-link scrollto" href="#contact">Kontak</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" >
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(<?= base_url(); ?>assets2/img/pondokpesantren.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">SELAMAT <span>DATANG</span></h2>
               <h2 class="animate__animated animate__fadeInDown" style="font-size: 16px;"><span>DI YAYASAN PENDIDIKAN ALISHLAH HAFIEZ ARRIDHO</span></h2><br><br>
               <p class="animate__animated animate__fadeInUp">Menjadikan kesatuan diri manusia yang utuh. Jiwa-nyawa-raga, hati-otak-tubuh, iman-ilmu-amal. Menghasilkan Lulusan Yang Berdedikasi Tinggi, Kreatif, Inovatif Dan Memiliki Etika</p>
              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">KUNJUNGI</a>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image: url(<?= base_url(); ?>assets2/img/pondokpesantren.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">PROFIL SEKOLAH</h2><br><br>
              <p class="animate__animated animate__fadeInUp">"Pendidikan Adalah Teman Yang Baik. Seseorang Yang Terdidik Akan Dihormati Di Manapun. Pendidikan Mengalahkan Kecantikan Dan Jiwa Muda". - Chanakya</p>

              <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">KUNJUNGI</a>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image: url(<?= base_url(); ?>assets2/img/pondokpesantren.jpg)">
          <div class="carousel-container">
            <div class="container">
              <h2 class="animate__animated animate__fadeInDown">PROGRAM KEJURUAN</h2><br><br>
               <p class="animate__animated animate__fadeInUp">Bagi Kami Kreativitas Merupakan Gerbang Masa Depan. Kreativitas Akan Mendorong Inovasi. Kami Membuat Proses Belajar Mengajar Menjadi Lebih Interaktif, Dengan Demikian Siswa Lebih Menyukai Proses Belajar.</p>
              <a href="#jurusan" class="btn-get-started animate__animated animate__fadeInUp scrollto">KUNJUNGI</a>
            </div>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Featured Services Section ======= -->
   <br>
   <br>
   <br>
   <!-- <section style="background: url(<?= base_url(); ?>assets2/img/1.jpeg);background-size:55px;">
     
   </section> -->
    <!-- ======= About Us Section ======= -->
    <section id="about" class="about" style="background: url(<?= base_url(); ?>assets2/img/ponpes.jpg);background-size:100%;">
      <div class="container">

        <div >
          <h2><strong>PROFIL</strong></h2>
          <p><I>Profil Yayasan Pendidikan Alislah Hafiez Arridho</I></p>

        </div>

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2">
            <img src="<?= base_url(); ?>assets2/img/ridho.jpg" class="img-thumbnail" style="border-radius: 10%;width: 600px;">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
             <h3 align="center"><i>Sekapur Sirih</i></h3>
            <p class="fst-italic" style="text-align: justify;">
             Puji dan Syukur Kami panjatkan atas Kehadirat Allah SWT karena berkat Rahmat dan Hidayah-Nya sehingga kami dapat menghadirkan website sekolah kami, tak lupa Shalawat dan Salam kepada Rasulullah Muhammad SAW yang telah membawa kita ke jalan yang lurus.
             Keberadaan sebuah website khususnya website sekolah di era global dan pesatnya Teknologi Informasi saat ini sangatlah penting. Begitupun dengan hadirnya website sekolah kami “Yayasan Pendidikan Alislah Hafiez Arridho” kami berharap dapat menjadi salah satu media penyebarluasan informasi dan dapat menjawab semua kebutuhan masyarakat tentang kondisi terbaru sekolah kami serta masyarakat dapat memanfaatkan sebagai sarana untuk berkomunikasi dengan kami<a href="<?= base_url('auth'); ?>" style="text-decoration:none;color: #000;">.</a>
            <h3 align="center"><i>Sejarah Yayasan Pendidikan Alislah Hafiez Arridho</i></h3>
            <p class="fst-italic" style="text-align: justify;">
              Bangunan yang sekarang dijadikan Yayasan Pendidikan Alislah Hafiez Arridho sudah ada sejak tahun 2025 . Dulu bangunan ini pernah dijadikan lahan pertanian dan perkebunan. Pada akhirnya di tahun 2025 Yayasan Pendidikan Alislah Hafiez Arridho mulai dirintis dan diurus surat izin operasionalnya.
            </p>
            
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <section id="visi" class="visi">
      <div class="container">

        <div align="center">
          <h2><strong>VISI & MISI</strong></h2>
         <p><I>Visi Misi Yayasan Pendidikan Alislah Hafiez Arridho</I></p>
        </div>

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2">
             <h3 align="center">Tujuan</h3>
            <ul class="fst-italic" style="text-align: justify;">
              <li><i class="bi bi-check-circled"></i> Membentuk pribadi muslim yang beriman, bertakwa, berakhlak mulia, dan berguna bagi masyarakat, agama, dan negara.</li>
            </ul>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <h3 align="center">Visi</h3>
            <p class="fst-italic" style="text-align: justify;">
              Menjadi lembaga pendidikan islam yang unggul, membentuk kader pemimpin yang berakhlak mulia, cerdas, dan berilmu luas, serta mampu menjawab tantangan zaman.
            </p>
            <h3 align="center">Misi</h3>
            <ul class="fst-italic" style="text-align: justify;">
              <li><i class="bi bi-check-circled"></i> Pengembangan intelektual dan spiritual santri (IPTEK dan IMTAQ), pembentukan karakter mulia, penanaman nilai-nilai luhur seperti takwa dan ikhlas, serta pembekalan keterampilan yang relevan dengan perkembangan zaman.</li>
            </ul>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->
    <section id="jurusan" class="jurusan">
      <div class="container">
        <div >
          <h2><strong>Ilmu Pendidikan</strong></h2>
         <p><I>Yayasan Pendidikan Alislah Hafiez Arridho</I></p>
        </div>
        <div >
          <h3><strong>Tahfidz</strong></h3>
        </div>

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2">
            <img src="<?= base_url(); ?>assets2/img/tahfidz.jpg" class="img-thumbnail" alt="Tahfidz" style="border-radius: 10%;">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <p class="fst-italic" style="text-align: justify;">
              Tahfidz adalah kegiatan menghafal Al-Qur'an secara berulang-ulang agar hafalannya utuh dan tidak terlupa, yang siswanya disebut hafidz (laki-laki) dan hafidzah (perempuan).
            </p>
            <p class="fst-italic" style="text-align: justify;">
              Kegiatan ini bertujuan untuk menjaga dan memelihara ayat-ayat suci Al-Qur'an di dalam ingatan, dan umumnya dilakukan dengan berbagai metode, seperti mengulang hafalan, mendengarkan bacaan, dan menyetorkan hafalan kepada guru.
            </p>
          </div>
    </section>

  

    <!-- ======= Guru Section ======= -->
   <section id="guru" class="guru">
        <div class="container">
          <div >
          <h2><strong>Guru</strong></h2>
          <p><i>Guru Yayasan Pendidikan Alislah Hafiez Arridho.</i></p>
        </div>
            <div class="row">
                <?php foreach ($data->result() as $row) : ?>
                    <div class="col-xs-12 col-sm-6 col-md-3">
                        <div class="admission_insruction">
                          <?php if(empty($row->foto)):?>
                            <img src="<?php echo base_url().'assets/img/avatar/user1.png';?>" class="img-thumbnail" style="border-radius: 10%;width: 550px;height: 300px;">
                          <?php else:?>
                            <img src="<?php echo base_url().'assets/img/avatar/'.$row->foto;?>" class="img-thumbnail" style="border-radius: 10%;width: 550px;height: 300px;">
                          <?php endif;?>
                            <p class="text-center mt-3"><span><strong><?php echo $row->nama_guru;?></strong></span>
                                <br>
                                <?php echo $row->status;?></p>
                        </div>
                    </div>
                <?php endforeach;?>
              </div>
            <!-- End row -->
            <nav><?php echo $page;?></nav>
        </div>
    </section>

    <!-- ======= Cta Section ======= -->
    

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio" style="background-color:#EBF3F3 ">
      <div class="container">

        <div>
          <h2><strong>Galeri</strong></h2>
          <p><i>Dokumentasi Kegiatan Yayasan Pendidikan Alislah Hafiez Arridho.</i></p>
        </div>

        <div class="row portfolio-container">

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan1.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 1</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Kegiatan Hiking Siswa/Siswi SMK Taruna Wiyata Mandala"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>


          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan2.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 2</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan2.jpg"  data-gallery="portfolioGallery" class="portfolio-lightbox" title="Kunjungan Pengawas"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan3.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 3</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Penyerahan cenderamata dari SMK TARUNA WIYATAMANDALA ke pembimbing PKL (Pa Asep) PT DIRGANTARA INDONESIA."><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

           <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan4.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 4</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan4.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Hiking Ke Curug Coang"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

           <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan5.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 5</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan5.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="PKKW2"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan6.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 6</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan6.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Pengecekan Verivikasi UKK"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan7.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 7</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan7.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Penyematan dan Peresmian Pelatihan Kecakapan Kewirausahaan Body Repair and Painting"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan8.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 8</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan8.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Foto Bersama Siswa/Siswi Jurusan RPL"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

           <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/kegiatan9.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <h4>Galeri 9</h4>
                <p></p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/kegiatan9.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Galeri 9"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Section -->

     <!-- <section id="sarana" class="sarana" style="background-color:#EBF3F3 ">
      <div class="container">

        <div >
          <h2><strong>Sarana Dan Prasarana</strong></h2>
          <p><i>Sarana Dan Prasarana SMK Taruna Wiyatamandala.</i></p>
        </div>

        <div class="row portfolio-container">

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/Lapang.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <p>Lapangan Upacara</p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/Lapang.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Lapangan Upacara"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>


          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/bkl.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <p>Bengkel dan Ruang Praktik</p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/bkl.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Bengkel dan Ruang Praktik"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

           <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/RK.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <p>Lab Komputer</p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/RK.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Lab Komputer"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

           <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="<?= base_url(); ?>assets2/img/sanlat.jpg" class="img-fluid" style="border-radius: 10%;">
              <div class="portfolio-info">
                <p>Mushola</p>
                <div class="portfolio-links">
                  <a href="<?= base_url(); ?>assets2/img/sanlat.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Mushola"><i class="bx bx-plus"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>-->
    <!-- End Portfolio Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div >
          <h2><strong>Kontak</strong></h2>
          <p><i>Lokasi Dan Kontak Yayasan Pendidikan Alislah Hafiez Arridho</i></p>
        </div>

        <div class="row">

          <div class="col-lg-7 d-flex align-items-stretch">
            <div class="info table-responsive" >
               <h3><font color="#04008e">Kunjungi Kami:</font></h3>
               <table class="table-responsive"><tr><th>
              <div class="address">
                 <a href="https://maps.app.goo.gl/MhQ438y8VsA2xMQo9" target="_BLANK"><i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>Dusun Kediri Desa Sidodadi Ramunia Kecamatan Beringin Kabupaten Deli Serdang Provinsi Sumatera Utara</p></a>
              </div>

              <div class="email">
                <a href="https://mail.google.com/" target="_BLANK"><i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>alislahhafiezarridho@gmail.com</p></a>
              </div>

              <div class="phone">
                <i class="bi bi-telephone"></i>
                <h4>Call:</h4>
                <p>085277816339</p>
              </div></th>
              <th><div class="phone">
                <a href="https://facebook.com/smktwmofficial" class="facebook" target="_BLANK"><i class="bi bi-facebook"></i>
                <h4>Facebook:</h4>
                <p>alislahhafiezarridhoofficial</p></a>
              </div>

              <div class="phone">
                <a href="https://www.instagram.com/smktwm_official" class="instagram" target="_BLANK"><i class="bi bi-instagram"></i>
                <h4>Instagram:</h4>
                <p>alislahhafiezarridho_official</p></a>
              </div>

            </th></tr></table>

            
              <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d418.5494861780087!2d98.88389802642946!3d3.6020828371420994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sid!2sid!4v1761616084628!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>

          </div>

          <div class="col-lg-5 mt-5 mt-lg-0 d-flex align-items-stretch">
            <div class="info" >
            <?= $this->session->flashdata('pesan'); ?>
                <?= form_open_multipart('contact/kirim_pesan'); ?>
           
              <div class="row">
                <h3><font color="#04008e">Customer Service</font></h3>
                <h5>Ajukan Pertanyaan Di Form Berikut</h5>
                <div class="form-group col-md-6">
                  <label>Nama Lengkap</label>
                  <input type="text" name="xnama" class="form-control"  required>
                </div>
                <div class="form-group col-md-6 mt-3 mt-md-0">
                  <label >Email</label>
                  <input type="email" class="form-control" name="xemail"  required>
                </div>
              </div>
              <div class="form-group mt-3">
                <label>Nomer Telepon</label>
                <input type="text" class="form-control" name="xphone"  required>
              </div>
              <div class="form-group mt-3">
                <label >Pesan/Pertanyaan</label>
                <textarea class="form-control" name="xmessage" rows="11" required></textarea>
              </div>
              <br>
              <div align="center"><button type="submit" style="width:100%;background-color:#04008e;" class="btn btn-primary btn-submit">Kirim</button></div>
              <br>
               <?= $this->session->flashdata('msg'); ?>
              <?= form_close(); ?>
          </div>
        </div>
        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright . 2019 - <?= date('Y') ?> . <strong><span>SMK Taruna Wiyatamandala</span></strong> . All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/green-free-one-page-bootstrap-template/ -->
        Designed by <a href="<?= base_url('home'); ?>"><font  color="#2DEDD3">Tech_Info19</font></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?= base_url(); ?>assets2/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url(); ?>assets2/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?= base_url(); ?>assets2/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?= base_url(); ?>assets2/vendor/php-email-form/validate.js"></script>
  <script src="<?= base_url(); ?>assets2/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url(); ?>assets2/js/main.js"></script>

</body>

</html>